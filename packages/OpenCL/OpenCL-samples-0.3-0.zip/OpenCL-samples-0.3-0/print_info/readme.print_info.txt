/*************************************************************************/
/*                                                                       */
/* Licensed Materials - Property of IBM                                  */
/*                                                                       */
/*                                                                       */
/* (C) Copyright IBM Corp. 2011                                          */
/* All Rights Reserved                                                   */
/*                                                                       */
/* US Government Users Restricted Rights - Use, duplication or           */
/* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.     */
/*                                                                       */
/*************************************************************************/

================================================================================
OVERVIEW
================================================================================

   Name: Print Platform and Device Information Sample

   This sample is a simple program that prints all queriable information 
   for each platform and all its available devices.  The heavy lifting is
   done using CLU's cluPrintPlatformInfo and cluPrintDeviceInfo functions.

   This sample is useful in discovering features of the OpenCL implementation
   without having to write a program.

================================================================================
PREREQUISITES
================================================================================

   None

================================================================================
HOW TO BUILD  
================================================================================

   Change to the OpenCL-samples-0.3-0 directory

       cd OpenCL-samples-0.3.0

   To build for 32-bit addressability, change to the ppc directory and type 
   "make":

       cd print_info/ppc
       make

   To build for 64-bit addressability, change to the ppc64 directory and type 
   "make":

       cd print_info/ppc64
       make

================================================================================
HOW TO RUN    
================================================================================

   To run enter:

       ./print_info

================================================================================
COMMAND LINE SYNTAX
================================================================================

   This program has no options. 

================================================================================
END OF TEXT
================================================================================