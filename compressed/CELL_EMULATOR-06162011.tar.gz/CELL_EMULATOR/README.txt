%% --------------------------------------------------------------- 
%% Licensed Materials - Property of IBM                            
%% 5724-S84                                                        
%% (C) Copyright IBM Corp. 2006,2009, All Rights Reserved          
%% US Government Users Restricted Rights - Use, duplication or     
%% disclosure restricted by GSA ADP Schedule Contract with         
%% IBM Corp.                                                       
%% --------------------------------------------------------------- 

======================================================================
README file for:

IBM Full System Simulator for the Cell Broadband Engine,
Version 3.1 update 
IBM Corp.
28 May 2009

======================================================================
Contents:

   Copyright statement
   About this release
   Statement of supported hardware and software
   Installation information
   Troubleshooting


======================================================================
Copyright statement

     Copyright (C) 2009 IBM Corporation


======================================================================
About this release

1. Edition notice

   This README applies to Version 3, Release 1 of the IBM(TM) Full 
   System Simulator for the Cell Broadband Engine.

2. Overview

   The IBM Full-System Simulator is a software application that emulates
   the behavior of a system containing one or multiple Cell Broadband
   Engine(TM) Processors. Users are able to boot a Linux operating
   system in the simulator and then, in turn, run applications on the
   simulated operating system. In addition to running applications, the
   simulator also supports the loading and running of statically-linked
   executables and stand-alone tests without an underlying operating
   system.

3. New features in this release

   The update to Version 3.1 fixes several bugs identified in the
   initial 3.1 release.


======================================================================
Statement of supported hardware and software

   The IBM Full System Simulator has an "as-is" support model, free of
   charge, provided via an IBM developerWorks Web forum on-line
   support. The IBM developerWorks discussion forums let you ask
   questions, share knowledge, ideas, and opinions about technologies
   and programming techniques with other developerWorks users. Use the
   forum content at your own risk. While IBM will attempt to provide a
   timely response to all postings, the use of this developerWorks forum
   does not guarantee a response to every question that is posted, nor
   do we validate the answers or the code that are offered.


======================================================================
Installation information

1. Prerequisites

   Hardware: The simulator is available for 32-bit and 64-bit i386 and
   64-bit PowerPC systems.  Certain simulator features are only
   available on 64-bit architectures.  The system should have at least
   1GB of memory available for use by the simulator.  Additional system
   memory may be required if the memory size of the simulated system is
   increased.

   Operating system: This version of the simulator is supported on
   Fedora Linux Release 9.  The simulator is also known to work on
   related platforms that provide equivalent versions of system
   libraries.

   Software: The simulator requires the tcl, tk, and xterm packages to
   be installed prior to installing the simulator.

2. Installation instructions

   Download the appropriate rpm package from the downloads tab and
   install (as root) with the command:

      rpm -Uvh systemsim-cell-<version>.<arch>.rpm 


======================================================================
Troubleshooting

1. Versions of Tcl and Tk.

   The simulator requires that the Tcl and Tk packages be installed on
   the system prior to installation.  However, the versions of Tcl and
   Tk contained in the original Fedora 9 distribution contain bugs that
   cause failures in the simulator.  If you are experiencing failures
   that appear involve the Tcl or Tk components, you should update the
   Tcl and Tk packages to the latest available versions.  If you use the
   yum update mechanism, you can do this with the following command:

      yum update tcl tk 

2. Stack overflow messages.

   Some versions of Tcl and Tk can generate a stream of stack overflow
   error messages when used with the simulator.  These messages have the
   form:

      error in background error handler:
      out of stack space (infinite loop?)
          while executing
      "::tcl::Bgerror {out of stack space (infinite loop?)} {..."

   You can suppress these messages by removing the limit on the stack
   size for processes launched by the shell.  To do this, issue the
   command

      ulimit -s unlimited 

   before starting the simulator.

3. Missing sysroot disk image.

   If the simulator displays the following message on startup

      ERROR: Failed to mount sysroot image. Is sysroot_image installed? 

   this generally means that this sysroot disk has not been installed.
   To check if the sysroot disk is installed, issue the command:

      rpm -q sysroot_image

   If the sysroot is not installed, you need to install it. To install
   the sysroot image from version 3.1 of the IBM SDK for Multicore
   Acceleration, you can download the rpm from 

      http://www.bsc.es/projects/deepcomputing/linuxoncell/cellsimulator/sdk3.1/CellSDK-Open-Fedora/cbea/sysroot_image-3.1-1.noarch.rpm

   and then install this rpm (as root) with the command 

      rpm -ivh sysroot_image-3.1-1.noarch.rpm

